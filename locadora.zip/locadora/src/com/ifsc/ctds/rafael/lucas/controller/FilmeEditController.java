package com.ifsc.ctds.rafael.lucas.controller;

import java.net.URL;
import java.util.ResourceBundle;

import com.ifsc.ctds.rafael.lucas.entity.Filme;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.stage.Stage;

public class FilmeEditController implements Initializable {

    @FXML
    private AnchorPane pnlPrincipal;

    @FXML
    private GridPane pnlDados;

    @FXML
    private Label lblTitulo;

    @FXML
    private TextField txtTitulo;

    @FXML
    private HBox pnlBotoes;

    @FXML
    private Button btnOK;

    @FXML
    private Button btnCancela;
    
	private Stage janelaFilmeEdit;

	private Filme filme;

	private boolean okClick = false;

    @FXML
    void onClickBtnCancela(ActionEvent event) {
    	this.getJanelaFilmeEdit().close();
    }

    @FXML
    void onClickBtnOK(ActionEvent event) {
		if (validarCampos()) {
			this.filme.setTitulo(this.txtTitulo.getText());

			this.okClick = true;
			this.getJanelaFilmeEdit().close();
		}
    }

	public Stage getJanelaFilmeEdit() {
		return janelaFilmeEdit;
	}

	public void setJanelaFilmeEdit(Stage janelaFilmeEdit) {
		this.janelaFilmeEdit = janelaFilmeEdit;
	}
	
	public void populaTela(Filme filme) {
		this.filme = filme;

		this.txtTitulo.setText(this.filme.getTitulo());
	}
	
	public boolean isOkClick() {
		return okClick;
	}

	private boolean validarCampos() {
		String mensagemErros = new String();

		if (this.txtTitulo.getText() == null || this.txtTitulo.getText().trim().length() == 0) {
			mensagemErros += "Informe o t�tulo!\n";
		}

		if (mensagemErros.length() == 0) {
			return true;
		} else {
			Alert alerta = new Alert(Alert.AlertType.ERROR);
			alerta.initOwner(this.janelaFilmeEdit);
			alerta.setTitle("Dados inv�lidos!");
			alerta.setHeaderText("Favor corrigir as seguintes informa��es:");
			alerta.setContentText(mensagemErros);
			alerta.showAndWait();

			return false;
		}
	}
    
	@Override
	public void initialize(URL location, ResourceBundle resources) {

	}

}
