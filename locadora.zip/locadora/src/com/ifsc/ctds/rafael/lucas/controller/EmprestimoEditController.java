package com.ifsc.ctds.rafael.lucas.controller;


import java.net.URL;
import java.sql.Date;
import java.util.ResourceBundle;

import com.ifsc.ctds.rafael.lucas.entity.Cliente;
import com.ifsc.ctds.rafael.lucas.entity.Emprestimo;
import com.ifsc.ctds.rafael.lucas.entity.Filme;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.stage.Stage;

public class EmprestimoEditController implements Initializable {

    @FXML
    private AnchorPane pnlPrincipal;

    @FXML
    private GridPane pnlDados;

    @FXML
    private Label lblDataEmprestimo;

    @FXML
    private Label lblDataDevolucao;

    @FXML
    private DatePicker dtpDataDevolucao;

    @FXML
    private Label lblCliente;

    @FXML
    private ComboBox<Cliente> cbxCliente;

    @FXML
    private Label lblFilme;

    @FXML
    private ComboBox<Filme> cbxFilme;

    @FXML
    private DatePicker dtpDataEmprestimo;

    @FXML
    private HBox pnlBotoes;

    @FXML
    private Button btnOK;

    @FXML
    private Button btnCancela;
    
	private Stage janelaEmprestimoEdit;

	private Emprestimo emprestimo;

	private boolean okClick = false;

	private ClienteListaController clienteListaController;
	private FilmeListaController filmeListaController;

    @FXML
    void onClickBtnCancela(ActionEvent event) {
    	this.getJanelaEmprestimoEdit().close();
    }

    @FXML
    void onClickBtnOK(ActionEvent event) {
    	if (validarCampos()) {
    		this.emprestimo.setDataEmprestimo(Date.valueOf(this.dtpDataEmprestimo.getValue()));
			this.emprestimo.setDataDevolucao(Date.valueOf(this.dtpDataDevolucao.getValue()));
			this.emprestimo.setCliente(this.cbxCliente.getSelectionModel().getSelectedItem());
			this.emprestimo.setFilme(this.cbxFilme.getSelectionModel().getSelectedItem());

			this.okClick = true;
			this.getJanelaEmprestimoEdit().close();
		}

    }
    
    @Override
    public void initialize(URL location, ResourceBundle resources) {
		this.clienteListaController = new ClienteListaController();
		this.filmeListaController = new FilmeListaController();

		this.carregarComboBoxClientes();
		this.carregarComboBoxFilme();
	}
    
    public Stage getJanelaEmprestimoEdit() {
		return janelaEmprestimoEdit;
	}

	public void setJanelaEmprestimoEdit(Stage janelaEmprestimoEdit) {
		this.janelaEmprestimoEdit = janelaEmprestimoEdit;
	}
    
    
    private boolean validarCampos() {
		String mensagemErros = new String();

		if (this.dtpDataEmprestimo.getValue() == null ) {
			mensagemErros += "Informe a data de empr�stimo!\n";
		}
		
		if (this.dtpDataDevolucao.getValue() == null ) {
			mensagemErros += "Informe a data de devolu��o!\n";
		}
		
		if (this.cbxCliente.getValue() == null ) {
			mensagemErros += "Informe o cliente!\n";
		}
		
		if (this.cbxFilme.getValue() == null ) {
			mensagemErros += "Informe o filme!\n";
		}

		if (mensagemErros.length() == 0) {
			return true;
		} else {
			Alert alerta = new Alert(Alert.AlertType.ERROR);
			alerta.initOwner(this.janelaEmprestimoEdit);
			alerta.setTitle("Dados inv�lidos!");
			alerta.setHeaderText("Favor corrigir as seguintes informa��es:");
			alerta.setContentText(mensagemErros);
			alerta.showAndWait();

			return false;
		}
	}
    
	public boolean isOkClick() {
		return okClick;
	}
	
	public void populaTela(Emprestimo emprestimo) {
		this.emprestimo = emprestimo;

		if (this.emprestimo.getDataEmprestimo() != null) {
			this.dtpDataEmprestimo.setValue(this.emprestimo.getDataEmprestimo().toLocalDate());
		}
		
		if (this.emprestimo.getDataDevolucao() != null) {
			this.dtpDataDevolucao.setValue(this.emprestimo.getDataDevolucao().toLocalDate());
		}

		if (this.emprestimo.getCliente() != null) {
			this.cbxCliente.setValue(this.emprestimo.getCliente());
		}

		if (this.emprestimo.getFilme() != null) {
			this.cbxFilme.setValue(this.emprestimo.getFilme());
		}
	}
	
	public void carregarComboBoxClientes() {
		ObservableList<Cliente> observableListaCliente = FXCollections
				.observableArrayList(this.clienteListaController.retornaListagemCliente());

		this.cbxCliente.setItems(observableListaCliente);
	}

	public void carregarComboBoxFilme() {
		ObservableList<Filme> observableListaFilme = FXCollections
				.observableArrayList(this.filmeListaController.retornaListagemFilme());

		this.cbxFilme.setItems(observableListaFilme);
	}

}

