package com.ifsc.ctds.rafael.lucas.controller;


import java.net.URL;
import java.sql.Date;
import java.text.SimpleDateFormat;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Optional;
import java.util.ResourceBundle;

import com.ifsc.ctds.rafael.lucas.dao.EmprestimoDAO;
import com.ifsc.ctds.rafael.lucas.entity.Emprestimo;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonBar;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Label;
import javafx.scene.control.SplitPane;
import javafx.scene.control.TableCell;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.Tooltip;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.GridPane;
import javafx.stage.Modality;
import javafx.stage.Stage;

public class EmprestimoListaController implements Initializable {

    @FXML
    private AnchorPane pnlPrincipal;

    @FXML
    private SplitPane pnlDivisao;

    @FXML
    private AnchorPane pnlEsquerda;

    @FXML
    private TableView<Emprestimo> tbvEmprestimos;

    @FXML
    private TableColumn<Emprestimo, Long> tbcCodigo;

    @FXML
    private TableColumn<Emprestimo, Date> tbcDataDevolucao;

    @FXML
    private AnchorPane pnlDireita;

    @FXML
    private Label lblDetalhes;

    @FXML
    private GridPane pnlDetalhes;

    @FXML
    private Label lblNomeCliente;

    @FXML
    private Label lblNomeClienteValor;

    @FXML
    private Label lblEmailCliente;

    @FXML
    private Label lblEmailClienteValor;

    @FXML
    private Label lblTituloFilme;

    @FXML
    private Label lblTituloFilmeValor;

    @FXML
    private Label lblDataEmprestimo;

    @FXML
    private Label lblDataEmprestimoValor;

    @FXML
    private ButtonBar barBotoes;

    @FXML
    private Button btnInclur;

    @FXML
    private Tooltip tlpIncluir;

    @FXML
    private Button btnEditar;

    @FXML
    private Tooltip tlpEditar;

    @FXML
    private Button btnExcluir;

    @FXML
    private Tooltip tlpExcluir;

	private List<Emprestimo> listaEmprestimos;
	private ObservableList<Emprestimo> observableListaEmprestimos = FXCollections.observableArrayList();
	private EmprestimoDAO emprestimoDAO;

	public static final String EMPRESTIMO_EDITAR = " - Editar";
	public static final String EMPRESTIMO_INCLUIR = " - Incluir";

	@FXML
	void onClickBtnEditar(ActionEvent event) {
		Emprestimo emprestimo = this.tbvEmprestimos.getSelectionModel().getSelectedItem();

		if (emprestimo != null) {
			boolean btnConfirmarClick = this.onShowTelaEmprestimoEditar(emprestimo, EmprestimoListaController.EMPRESTIMO_EDITAR);

			if (btnConfirmarClick) {
				this.getEmprestimoDAO().update(emprestimo, null);
				this.carregarTableViewEmprestimos();
			}
		} else {
			Alert alerta = new Alert(Alert.AlertType.ERROR);
			alerta.setContentText("Por favor, escolha um empr�stimo na tabela!");
			alerta.show();
		}
	}

	@FXML
	void onClickBtnExcluir(ActionEvent event) {
		Emprestimo emprestimo = this.tbvEmprestimos.getSelectionModel().getSelectedItem();

		if (emprestimo != null) {

			Alert alerta = new Alert(AlertType.CONFIRMATION);
			alerta.setTitle("Pergunta");
			alerta.setHeaderText("Confirma a exclus�o do empr�stimo?\n" + emprestimo.getFilme().getTitulo());

			ButtonType botaoNao = ButtonType.NO;
			ButtonType botaoSim = ButtonType.YES;
			alerta.getButtonTypes().setAll(botaoSim, botaoNao);
			Optional<ButtonType> resultado = alerta.showAndWait();

			if (resultado.get() == botaoSim) {
				this.getEmprestimoDAO().delete(emprestimo);
				this.carregarTableViewEmprestimos();
			}
		} else {
			Alert alerta = new Alert(Alert.AlertType.ERROR);
			alerta.setContentText("Por favor, escolha um empr�stimo na tabela!");
			alerta.show();
		}
	}

	@FXML
	void onClickBtnIncluir(ActionEvent event) {
		Emprestimo emprestimo = new Emprestimo();

		boolean btnConfirmarClick = this.onShowTelaEmprestimoEditar(emprestimo, EmprestimoListaController.EMPRESTIMO_INCLUIR);

		if (btnConfirmarClick) {
			this.getEmprestimoDAO().save(emprestimo);
			this.carregarTableViewEmprestimos();
		}

	}
	
	public EmprestimoDAO getEmprestimoDAO() {
		return emprestimoDAO;
	}
	
	public void setEmprestimoDAO(EmprestimoDAO emprestimoDAO) {
		this.emprestimoDAO = emprestimoDAO;
	}
	
	public boolean onCloseQuery() {
		Alert alerta = new Alert(Alert.AlertType.CONFIRMATION);
		alerta.setTitle("Pergunta");
		alerta.setHeaderText("Deseja sair do cadastro de empr�stimo?");
		ButtonType buttonTypeNO = ButtonType.NO;
		ButtonType buttonTypeYES = ButtonType.YES;
		alerta.getButtonTypes().setAll(buttonTypeYES, buttonTypeNO);
		Optional<ButtonType> result = alerta.showAndWait();
		return result.get() == buttonTypeYES ? true : false;
	}
	
	public boolean onShowTelaEmprestimoEditar(Emprestimo emprestimo, String operacao) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/ifsc/ctds/rafael/lucas/view/EmprestimoEdit.fxml"));
			Parent emprestimoEditXML = loader.load();

			Stage janelaEmprestimoEditar = new Stage();
			janelaEmprestimoEditar.setTitle("Cadastro de empr�stimo" + operacao);
			janelaEmprestimoEditar.initModality(Modality.APPLICATION_MODAL);
			janelaEmprestimoEditar.resizableProperty().setValue(Boolean.FALSE);

			Scene emprestimoEditLayout = new Scene(emprestimoEditXML);
			janelaEmprestimoEditar.setScene(emprestimoEditLayout);

			EmprestimoEditController emprestimoEditController = loader.getController();
			emprestimoEditController.setJanelaEmprestimoEdit(janelaEmprestimoEditar);
			emprestimoEditController.populaTela(emprestimo);

			janelaEmprestimoEditar.showAndWait();

			return emprestimoEditController.isOkClick();

		} catch (Exception e) {
			e.printStackTrace();
		}

		return false;
	}
	
	public List<Emprestimo> getListaEmprestimos() {
		return listaEmprestimos;
	}
	
	public void setListaEmprestimos(List<Emprestimo> listaEmprestimos) {
		this.listaEmprestimos = listaEmprestimos;
	}
	
	public void setObservableListaEmprestimos(ObservableList<Emprestimo> observableListaEmprestimos) {
		this.observableListaEmprestimos = observableListaEmprestimos;
	}
	
	public ObservableList<Emprestimo> getObservableListaEmprestimos() {
		return observableListaEmprestimos;
	}
	
	public void carregarTableViewEmprestimos() {
		this.tbcCodigo.setCellValueFactory(new PropertyValueFactory<>("id"));	
	    this.tbcDataDevolucao.setCellValueFactory(new PropertyValueFactory<>("dataDevolucao"));

	    this.tbcDataDevolucao.setCellFactory(column -> {
	        return new TableCell<Emprestimo, Date>() {
	            @Override
	            protected void updateItem(Date item, boolean empty) {
	                super.updateItem(item, empty);
	                if (item == null || empty) {
	                    setText(null);
	                } else {
	                    SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");
	                    setText(sdf.format(item));
	                }
	            }
	        };
	    });

		this.setListaEmprestimos(this.getEmprestimoDAO().getAll());
		this.setObservableListaEmprestimos(FXCollections.observableArrayList(this.getListaEmprestimos()));
		this.tbvEmprestimos.setItems(this.getObservableListaEmprestimos());
	}
	
	public void selecionarItemTableViewEmprestimos(Emprestimo emprestimo) {
		
		if (emprestimo != null) {
			this.lblNomeClienteValor.setText(emprestimo.getCliente().getNome());
			this.lblEmailClienteValor.setText(emprestimo.getCliente().getEmail());
			this.lblTituloFilmeValor.setText(emprestimo.getFilme().getTitulo());
			
			DateTimeFormatter dataFormatada = DateTimeFormatter.ofPattern("dd-MM-yyyy");
			String dataEmprestimoFormatada = emprestimo.getDataEmprestimo().toLocalDate().format(dataFormatada).toString();
			
			this.lblDataEmprestimoValor.setText(dataEmprestimoFormatada);
		} else {
			this.lblNomeClienteValor.setText("");
			this.lblEmailClienteValor.setText("");
			this.lblTituloFilmeValor.setText("");
			this.lblDataEmprestimoValor.setText("");
		}
	}
	
	@Override
	public void initialize(URL location, ResourceBundle resource) {
		this.setEmprestimoDAO(new EmprestimoDAO());
		this.carregarTableViewEmprestimos();
		this.selecionarItemTableViewEmprestimos(null);

		this.tbvEmprestimos.getSelectionModel().selectedItemProperty()
				.addListener((observable, oldValue, newValue) -> selecionarItemTableViewEmprestimos(newValue));
	}

}

