package com.ifsc.ctds.rafael.lucas.controller;

import java.net.URL;
import java.util.ResourceBundle;

import com.ifsc.ctds.rafael.lucas.entity.Cliente;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.stage.Stage;

public class ClienteEditController implements Initializable{

    @FXML
    private AnchorPane pnlPrincipal;

    @FXML
    private GridPane pnlDados;

    @FXML
    private Label lblNome;

    @FXML
    private TextField txtNome;

    @FXML
    private Label lblLogin;

    @FXML
    private TextField txtLogin;

    @FXML
    private Label lblEmail;

    @FXML
    private TextField txtEmail;

    @FXML
    private HBox pnlBotoes;

    @FXML
    private Button btnOK;

    @FXML
    private Button btnCancela;
    
	private Stage janelaClienteEdit;

	private Cliente cliente;

	private boolean okClick = false;

    @FXML
    void onClickBtnCancela(ActionEvent event) {
    	this.getJanelaClienteEdit().close();
    }

    @FXML
    void onClickBtnOK(ActionEvent event) {
    	if (validarCampos()) {
			this.cliente.setNome(this.txtNome.getText());
			this.cliente.setLogin(this.txtLogin.getText());
			this.cliente.setEmail(this.txtEmail.getText());

			this.okClick = true;
			this.getJanelaClienteEdit().close();
		}
    }
    
    public Stage getJanelaClienteEdit() {
		return janelaClienteEdit;
	}

	public void setJanelaClienteEdit(Stage janelaClienteEdit) {
		this.janelaClienteEdit = janelaClienteEdit;
	}
	
	public void populaTela(Cliente cliente) {
		this.cliente = cliente;

		this.txtNome.setText(cliente.getNome());
		this.txtLogin.setText(cliente.getLogin());
		this.txtEmail.setText(cliente.getEmail());
	}
	
	public boolean isOkClick() {
		return okClick;
	}
	
	private boolean validarCampos() {
		String mensagemErros = new String();

		if (this.txtNome.getText() == null || this.txtNome.getText().trim().length() == 0) {
			mensagemErros += "Informe o nome!\n";
		}

		if (this.txtLogin.getText() == null || this.txtLogin.getText().trim().length() == 0) {
			mensagemErros += "Informe o login!\n";
		}
		
		if (this.txtEmail.getText() == null || this.txtEmail.getText().trim().length() == 0) {
			mensagemErros += "Informe o email!\n";
		}
		
		if (mensagemErros.length() == 0) {
			return true;
		} else {
			Alert alerta = new Alert(Alert.AlertType.ERROR);
			alerta.initOwner(this.janelaClienteEdit);
			alerta.setTitle("Dados inv�lidos!");
			alerta.setHeaderText("Favor corrigir as seguintes informa��es:");
			alerta.setContentText(mensagemErros);
			alerta.showAndWait();

			return false;
		}
	}

	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		// TODO Auto-generated method stub
		
	}
}

